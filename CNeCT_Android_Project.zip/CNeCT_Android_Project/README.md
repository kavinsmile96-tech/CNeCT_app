# CNeCT Android app project

This is an Android Studio project that wraps your supplied Wholesale Order & Bill Tracker HTML in an Android WebView app named **CNeCT**.

## App branding
- Uses the CNeCT logo image supplied by you as the Android launcher icon.

## Included functionality
- Orders & bills, quick bill entry, search and filters
- Multi-item order builder and GST calculations
- Wholesaler contacts and balances
- Payment entry and payment history
- WhatsApp order/message sharing
- Analytics chart
- CSV export and JSON backup/restore using Android's file picker
- Shop profile and print reports
- Persistent WebView local storage on the device

## Build the APK
This environment does not have the Android SDK or Gradle installed, so it cannot compile/sign an APK here. Build the included project with Android Studio:

1. Install Android Studio on a computer.
2. Open the `CNeCT_Android_Project` folder.
3. Allow Android Studio to install the Android SDK (API 35) and sync Gradle.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK. The usual debug APK path is `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager/browser.

## Important notes
- The app stores bills, contacts, catalog and shop profile locally on the device using WebView local storage. Keep using the in-app JSON backup regularly.
- The first load needs internet for the existing Tailwind CSS, Chart.js and Google Fonts CDN resources in the original HTML. The app's saved data remains local.
- WhatsApp sharing opens WhatsApp when installed; otherwise Android offers another compatible app.
- The Android wrapper does not upload your business data to a server.


## Build free using GitHub Actions (phone-friendly)
1. Create a new public or private GitHub repository.
2. Upload this ZIP file to the repository root with the exact name `CNeCT_Android_Project.zip`.
3. In GitHub, choose **Add file → Create new file** and enter `.github/workflows/android.yml`.
4. Paste the workflow contents from this project's `.github/workflows/android.yml` and commit it to `main`.
5. Open the repository's **Actions** tab, select **Build CNeCT APK**, choose **Run workflow**, and run it on `main`.
6. When the run completes successfully, open the run and download the **CNeCT-debug-apk** artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
